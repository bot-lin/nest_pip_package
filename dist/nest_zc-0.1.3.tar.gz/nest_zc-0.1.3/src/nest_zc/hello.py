def say_hello(name: str = "world") -> str:
    return f"Hello, {name} from zc!"
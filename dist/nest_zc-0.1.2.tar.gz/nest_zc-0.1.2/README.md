# nest

A tiny example package.

## Usage

```bash
pip install nest
yourpkg-hello

**LICENSE**  
Pick one (e.g., MIT). Paste the license text.

**tests/test_hello.py**
```python
from yourpkg import say_hello

def test_say_hello():
    assert say_hello("Alice") == "Hello, Alice!"